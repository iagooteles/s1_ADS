public class App {
    public static void main(String[] args) throws Exception {
        Pessoa iago = new Pessoa("Iago", 1995, 90.0, 1.80);
        iago.mostra();
    }
}
